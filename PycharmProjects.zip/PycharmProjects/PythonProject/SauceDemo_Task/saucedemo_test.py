from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import time

# Test Data
URL = "https://www.saucedemo.com/"
USERNAME = "standard_user"
PASSWORD = "secret_sauce"


def login(driver):
    """Login to SauceDemo"""

    driver.get(URL)

    driver.find_element(By.ID, "user-name").send_keys(USERNAME)
    driver.find_element(By.ID, "password").send_keys(PASSWORD)
    driver.find_element(By.ID, "login-button").click()


def task1_verify_cart(driver, sort_option):
    """
    Task 1:
    - Sort products
    - Add first product after sorting
    - Verify product name, price and quantity in cart
    """

    # Select sorting option
    sort_dropdown = Select(
        driver.find_element(By.CLASS_NAME, "product_sort_container")
    )
    sort_dropdown.select_by_value(sort_option)

    # Capture first product details
    first_product = driver.find_elements(
        By.CLASS_NAME,
        "inventory_item"
    )[0]

    expected_name = first_product.find_element(
        By.CLASS_NAME,
        "inventory_item_name"
    ).text

    expected_price = first_product.find_element(
        By.CLASS_NAME,
        "inventory_item_price"
    ).text

    # Add to cart
    first_product.find_element(
        By.TAG_NAME,
        "button"
    ).click()

    # Open cart
    driver.find_element(
        By.CLASS_NAME,
        "shopping_cart_link"
    ).click()

    # Actual values from cart
    actual_name = driver.find_element(
        By.CLASS_NAME,
        "inventory_item_name"
    ).text

    actual_price = driver.find_element(
        By.CLASS_NAME,
        "inventory_item_price"
    ).text

    actual_quantity = driver.find_element(
        By.CLASS_NAME,
        "cart_quantity"
    ).text

    # Verifications
    assert actual_name == expected_name, \
        f"Product Name Mismatch: {actual_name} != {expected_name}"

    assert actual_price == expected_price, \
        f"Price Mismatch: {actual_price} != {expected_price}"

    assert actual_quantity == "1", \
        f"Quantity Mismatch: {actual_quantity}"

    print(f"\nPASS - Sort Option: {sort_option}")
    print(f"Product : {actual_name}")
    print(f"Price   : {actual_price}")
    print(f"Quantity: {actual_quantity}")


def task2_extract_products(driver):
    """
    Task 2:
    Extract first 3 products and prices
    after Name Z to A sorting
    """

    sort_dropdown = Select(
        driver.find_element(By.CLASS_NAME, "product_sort_container")
    )
    sort_dropdown.select_by_value("za")

    products = driver.find_elements(
        By.CLASS_NAME,
        "inventory_item"
    )

    print("\n==============================")
    print("First 3 Products After Z-A Sort")
    print("==============================")

    for product in products[:3]:

        title = product.find_element(
            By.CLASS_NAME,
            "inventory_item_name"
        ).text

        price = product.find_element(
            By.CLASS_NAME,
            "inventory_item_price"
        ).text

        print(f"{title} --> {price}")


def main():

    driver = webdriver.Chrome(
        service=Service(
            ChromeDriverManager().install()
        )
    )

    driver.maximize_window()

    # Task 1
    sort_options = [
        "lohi",   # Price Low to High
        "hilo",   # Price High to Low
        "az"      # Name A to Z
    ]

    for option in sort_options:

        login(driver)

        task1_verify_cart(driver, option)

        driver.get(URL)

    # Task 2
    login(driver)

    task2_extract_products(driver)

    time.sleep(3)
    driver.quit()


if __name__ == "__main__":
    main()